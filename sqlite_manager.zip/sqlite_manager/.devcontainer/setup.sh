#!/bin/bash
set -e

echo "========================================="
echo "  SQLite Manager - Dev Environment Setup"
echo "========================================="

# ── System dependencies ──────────────────────
echo "[1/5] Installing system dependencies..."
sudo apt-get update -q
sudo apt-get install -y -q \
  curl git unzip xz-utils zip libglu1-mesa \
  clang cmake ninja-build pkg-config \
  libgtk-3-dev liblzma-dev libstdc++-12-dev \
  libsqlite3-dev wget

# ── Flutter SDK ──────────────────────────────
echo "[2/5] Installing Flutter SDK..."
FLUTTER_VERSION="3.24.0"
if [ ! -d "$HOME/flutter" ]; then
  git clone https://github.com/flutter/flutter.git \
    -b stable --depth 1 "$HOME/flutter"
fi

export PATH="$PATH:$HOME/flutter/bin"
echo 'export PATH="$PATH:$HOME/flutter/bin"' >> ~/.zshrc
echo 'export PATH="$PATH:$HOME/flutter/bin"' >> ~/.bashrc

flutter precache --linux --web
flutter config --enable-linux-desktop
flutter config --enable-web

# ── Android SDK ──────────────────────────────
echo "[3/5] Installing Android SDK..."
ANDROID_SDK_ROOT="$HOME/android-sdk"
mkdir -p "$ANDROID_SDK_ROOT/cmdline-tools"

CMD_TOOLS_URL="https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip"
wget -q "$CMD_TOOLS_URL" -O /tmp/cmdline-tools.zip
unzip -q /tmp/cmdline-tools.zip -d /tmp/cmdtools
mv /tmp/cmdtools/cmdline-tools "$ANDROID_SDK_ROOT/cmdline-tools/latest"
rm -rf /tmp/cmdtools /tmp/cmdline-tools.zip

export ANDROID_SDK_ROOT="$ANDROID_SDK_ROOT"
export PATH="$PATH:$ANDROID_SDK_ROOT/cmdline-tools/latest/bin:$ANDROID_SDK_ROOT/platform-tools"

echo 'export ANDROID_SDK_ROOT="$HOME/android-sdk"' >> ~/.zshrc
echo 'export PATH="$PATH:$ANDROID_SDK_ROOT/cmdline-tools/latest/bin:$ANDROID_SDK_ROOT/platform-tools"' >> ~/.zshrc

yes | sdkmanager --licenses > /dev/null 2>&1 || true
sdkmanager --quiet \
  "platform-tools" \
  "platforms;android-34" \
  "build-tools;34.0.0" \
  "ndk;26.1.10909125"

# ── Flutter project setup ─────────────────────
echo "[4/5] Setting up Flutter project..."
cd /workspaces/sqlite_manager 2>/dev/null || cd "$HOME"
flutter pub get 2>/dev/null || true

# ── Flutter doctor ────────────────────────────
echo "[5/5] Running flutter doctor..."
flutter doctor --android-licenses 2>/dev/null || true
flutter doctor

echo ""
echo "✅ Setup complete!"
echo ""
echo "Quick start commands:"
echo "  flutter run -d web-server --web-port=8080 --web-hostname=0.0.0.0"
echo "  flutter test"
echo "  flutter test -d linux"
echo "  flutter build apk"
